﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq.Mapping;
using System.Data.Linq;
using System.Data.SqlClient;

namespace AdjustmentOfEquipment
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connectionString = @"Data Source=wsr;Initial Catalog=postovalov;User ID=postovalov;Password=1q@w3ezM";
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnEnter_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text;
            string password = txtPassword.Text;
            string name = "";
            string role = "";
            DataContext db = new DataContext(connectionString);
            Table<Classes.Users> users = db.GetTable<Classes.Users>();
            bool connected = false;

            try
            {
                foreach (var item in users)
                {
                    if ((item.username == login) && (item.password == password))
                    {
                        connected = true;
                        name = item.fio;
                        role = item.admin;
                    }

                }
                if (connected)
                {
                    MessageBox.Show("Здравствуй, " + name);
                    Main ManagerWindow = new Main();
                    ManagerWindow.role = role;
                    ManagerWindow.Show();
                    Close();
                }
                else
                {
                    MessageBox.Show("Введите корректные данные");

                }
            }
            catch
            {
                MessageBox.Show("Соединение не установлено");
            }
        }



        private void lblReg_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            Registration register = new Registration();
            register.Show();
            Close();
        }
    }
}
