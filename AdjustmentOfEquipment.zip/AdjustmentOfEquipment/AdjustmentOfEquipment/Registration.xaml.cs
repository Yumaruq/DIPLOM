﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq.Mapping;
using System.Data.Linq;
using System.Data;

namespace AdjustmentOfEquipment
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        string connectionString = @"Data Source=wsr;Initial Catalog=postovalov;User ID=postovalov;Password=1q@w3ezM";
        public Registration()
        {
            InitializeComponent();
        }

        private void BtnReg_Click(object sender, RoutedEventArgs e)
        {
            DataContext db = new DataContext(connectionString);
            if
                (txtFIOreg.Text != "" && txtLOGreg.Text != "" && txtPASSWORDreg.Text != "")
            {
                Classes.Users newUser = new Classes.Users { fio = txtFIOreg.Text, username = txtLOGreg.Text, password = txtPASSWORDreg.Text, admin = "adjuster", status = true };
                db.GetTable<Classes.Users>().InsertOnSubmit(newUser);
                db.SubmitChanges();

                MessageBox.Show("Пользователь зарегистрирован");
                MainWindow Авторизация = new MainWindow();
                Авторизация.Show();
                Close();
            }
            else
            {
                MessageBox.Show("Введите корректные данные");
            }
           
        }

    

        private void lblBack_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
            MainWindow Авторизация = new MainWindow();
            Авторизация.Show();
            Close();
        }
    }
}

