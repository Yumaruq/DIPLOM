﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Linq.Mapping;
using System.Data.Linq;
using System.Data.SqlClient;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace AdjustmentOfEquipment
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : System.Windows.Window
    {
        int redTech = 0;
        int redPers = 0;
        int redAct = 0;
        public string role = "";
        string connectionString = @"Data Source=wsr;Initial Catalog=postovalov;User ID=postovalov;Password=1q@w3ezM";
        public Main()
        {
            InitializeComponent();
        }
        // Обновление таблиц
        public void UpdateData()
        {
            DataContext dc = new DataContext(connectionString);
            //Оборудование
            Table<Classes.Tech> tech = dc.GetTable<Classes.Tech>();
            var st = (from s in tech
                      where s.status == true
                      select s);


            //Сотрудники
            Table<Classes.Users> pers = dc.GetTable<Classes.Users>();
            var tt = (from s in pers
                      where s.status == true
                      select s);

            // Акты
            Table<Classes.Act> act = dc.GetTable<Classes.Act>();
            var vt = (from s in act
                      where s.status == true
                      select s);



            dataAct1.ItemsSource = vt;
            dataPers.ItemsSource = tt;
            dataTech.ItemsSource = st;
            dataAct.ItemsSource = vt;


        }

        // Поиск сотрудников
        private void TxtPoisk3_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtPoisk3.Text != "")
            {
                DataContext dc = new DataContext(connectionString);
                Table<Classes.Users> tech = dc.GetTable<Classes.Users>();

                var st = (from s in tech
                          where s.status == true && s.fio.Contains(txtPoisk2.Text)
                          select s);

                dataPers.ItemsSource = st;
            }
            else
            {
                UpdateData();
            }
        }
        // Обновление ComboBox

        public void UpdateCmb()
        {
            DataContext dc = new DataContext(connectionString);
            //Отображение налогов
            Table<Classes.Users> taxTypes = dc.GetTable<Classes.Users>();

            var s = (from ttes in taxTypes
                     select ttes.fio);
            cmbFIO.ItemsSource = s;
            cmbFIO1.ItemsSource = s;

            Table<Classes.Tech> periods = dc.GetTable<Classes.Tech>();

            var s1 = (from per in periods
                      select per.NameOfTech);
            cmbTech.ItemsSource = s1;
            cmbTech1.ItemsSource = s1;


        }




        private void txtPoisk2_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtPoisk2.Text != "")
            {
                DataContext dc = new DataContext(connectionString);
                Table<Classes.Tech> tech = dc.GetTable<Classes.Tech>();

                var st = (from s in tech
                          where s.status == true && s.NameOfTech.Contains(txtPoisk2.Text)
                          select s);

                dataTech.ItemsSource = st;
            }
            else
            {
                UpdateData();
            }
        }


        // Новое оборудование
        private void btnNewTech_Click(object sender, RoutedEventArgs e)
        {
            txtNameOfTech.IsEnabled = true;



            btnEnter.IsEnabled = true;
            btnOtm.IsEnabled = true;
        }
        // Кнопка Отмена
        private void btnOtm_Click(object sender, RoutedEventArgs e)
        {

            txtNameOfTech.Text = "";


            txtNameOfTech.IsEnabled = false;
            btnDel.IsEnabled = false;
            btnEnter.IsEnabled = false;
            btnRed.IsEnabled = false;
            btnOtm.IsEnabled = false;


            btnNewTech.IsEnabled = true;
        }
        // Удаление оборудования
        private void btnDel_Click(object sender, RoutedEventArgs e)
        {// Удаление 
         // Получение ID 
            object item = dataTech.SelectedItem;
            long vb = Convert.ToInt64((dataTech.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            DataContext dc = new DataContext(connectionString);
            Table<Classes.Tech> tech = dc.GetTable<Classes.Tech>();
            Classes.Tech pr = tech.FirstOrDefault(pre => pre.Id.Equals(vb));

            pr.status = false; // Смена статуса True на False
            var SelectQuery =
                from a in tech
                select a;

            dc.SubmitChanges();
            dataTech.ItemsSource = SelectQuery;

            UpdateData();
            MessageBox.Show("Оборудование удалено");

        }

        // Кнопка Редактировать
        private void btnRed_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Доступность 
                txtNameOfTech.IsEnabled = true;


                btnOtm.IsEnabled = true;

                btnNewTech.IsEnabled = false;

                DataContext dc = new DataContext(connectionString);
                Table<Classes.Tech> tech = dc.GetTable<Classes.Tech>();

                // Редактирование
                object item = dataTech.SelectedItem;
                long vb = Convert.ToInt64((dataTech.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                txtNameOfTech.Text = (from sp in tech
                                      where sp.Id == vb
                                      select sp.NameOfTech).FirstOrDefault(); // Получение названия оборудования



                btnEnter.IsEnabled = true;
                btnRed.IsEnabled = true;

                redTech = 1;
            }
            catch { }
        }

        // Кнопка добавления оборудования
        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            // Добавление данных
            try
            {

                if (redTech == 0)
                {
                    if (txtNameOfTech.Text != "") // Проверка полей
                    {
                        DataContext dc = new DataContext(connectionString);





                        // Добавление в базу
                        Classes.Tech newtech = new Classes.Tech { NameOfTech = txtNameOfTech.Text, status = true, };
                        dc.GetTable<Classes.Tech>().InsertOnSubmit(newtech);
                        dc.SubmitChanges();

                        UpdateData(); // Обновление таблиц

                        MessageBox.Show("Оборудование добавлено"); // Вывод сообщения
                    }
                    else
                    {
                        MessageBox.Show("Заполните все поля"); // Вывод сообщения
                    }
                }


                //Редактирование 
                else
                {
                    object item = dataTech.SelectedItem;
                    long vb = Convert.ToInt64((dataTech.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                    DataContext dc = new DataContext(connectionString);
                    Table<Classes.Tech> tech = dc.GetTable<Classes.Tech>();
                    Classes.Tech pr = tech.FirstOrDefault(pre => pre.Id.Equals(vb));

                    pr.NameOfTech = txtNameOfTech.Text;
                    pr.status = true;

                    var SelectQuery =
                        from a in tech
                        select a;

                    dc.SubmitChanges();
                    dataTech.ItemsSource = SelectQuery;

                    UpdateData(); // Обновление таблиц
                    MessageBox.Show("Данные изменены");
                    redTech = 0;
                }

                txtNameOfTech.Text = "";


                txtNameOfTech.IsEnabled = false;

                btnDel.IsEnabled = false;
                btnEnter.IsEnabled = false;
                btnRed.IsEnabled = false;
                btnOtm.IsEnabled = false;

                btnNewTech.IsEnabled = true;
            }

            catch { }
        }


        // Таблица оборудования
        private void dataTech_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnDel.IsEnabled = true;
            btnRed.IsEnabled = true;
        }
        // Редактирование Сотрудников
        private void BtnRed2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Доступность 
                txtFIO.IsEnabled = true;


                btnOtm2.IsEnabled = true;

                btnNewPers.IsEnabled = false;

                btnEnter2.IsEnabled = true;

                DataContext dc = new DataContext(connectionString);
                Table<Classes.Users> tech = dc.GetTable<Classes.Users>();

                // Редактирование
                object item = dataPers.SelectedItem;
                long vb = Convert.ToInt64((dataPers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);

                txtFIO.Text = (from sp in tech
                               where sp.id == vb
                               select sp.fio).FirstOrDefault(); // Получение ФИО




                btnRed2.IsEnabled = true;

                redPers = 1;
            }
            catch { }
        }
        // Удаление сотрудников
        private void BtnDel2_Click(object sender, RoutedEventArgs e)
        {
            // Получение ID 
            object item = dataPers.SelectedItem;
            long vb = Convert.ToInt64((dataPers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            DataContext dc = new DataContext(connectionString);
            Table<Classes.Users> pers = dc.GetTable<Classes.Users>();
            Classes.Users pr = pers.FirstOrDefault(pre => pre.id.Equals(vb));

            pr.status = false; // Смена статуса True на False
            var SelectQuery =
                from a in pers
                select a;

            dc.SubmitChanges();
            dataPers.ItemsSource = SelectQuery;

            UpdateData();
            MessageBox.Show("Сотрудник удален");
        }
        // Кнопка отмена
        private void BtnOtm2_Click(object sender, RoutedEventArgs e)
        {
            txtFIO.Text = "";


            txtFIO.IsEnabled = false;
            btnDel2.IsEnabled = false;
            btnEnter2.IsEnabled = false;
            btnRed2.IsEnabled = false;
            btnOtm2.IsEnabled = false;

            btnNewPers.IsEnabled = true;
        }





        // Кнопка Добавить

        private void BtnEnter2_Click(object sender, RoutedEventArgs e)
        {
            // Добавление данных
            try
            {

                if (redPers == 0)
                {
                    if (txtFIO.Text != "") // Проверка полей
                    {
                        DataContext dc = new DataContext(connectionString);
                        // Добавление в базу
                        Classes.Users newpers = new Classes.Users { fio = txtFIO.Text, status = true, };
                        dc.GetTable<Classes.Users>().InsertOnSubmit(newpers);
                        dc.SubmitChanges();

                        UpdateData(); // Обновление таблиц

                        MessageBox.Show("Сотрудник добавлен"); // Вывод сообщения
                    }
                    else
                    {
                        MessageBox.Show("Заполните все поля"); // Вывод сообщения
                    }
                }


                //Редактирование 
                else
                {
                    object item = dataPers.SelectedItem;
                    long vb = Convert.ToInt64((dataPers.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                    DataContext dc = new DataContext(connectionString);
                    Table<Classes.Users> tech = dc.GetTable<Classes.Users>();
                    Classes.Users pr = tech.FirstOrDefault(pre => pre.id.Equals(vb));

                    pr.fio = txtFIO.Text;
                    pr.status = true;

                    var SelectQuery =
                        from a in tech
                        select a;

                    dc.SubmitChanges();
                    dataPers.ItemsSource = SelectQuery;

                    UpdateData(); // Обновление таблиц
                    MessageBox.Show("Данные изменены");
                    redPers = 0;
                }

                txtFIO.Text = "";


                txtFIO.IsEnabled = false;

                btnDel2.IsEnabled = false;
                btnEnter2.IsEnabled = false;
                btnRed2.IsEnabled = false;
                btnOtm2.IsEnabled = false;

                btnNewPers.IsEnabled = true;
            }

            catch { }
        }

        // Новый сотрудник
        private void btnNewPers_Click(object sender, RoutedEventArgs e)
        {
            txtFIO.IsEnabled = true;



            btnEnter2.IsEnabled = true;
            btnOtm2.IsEnabled = true;
        }

        private void dataPers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnDel2.IsEnabled = true;
            btnRed2.IsEnabled = true;
        }

        private void cmbFIO_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateCmb();


        }
        // Кнопка Добавить
        private void btnEnter3_Click(object sender, RoutedEventArgs e)
        {
            // Добавление данных
            try
            {

                if (redAct == 0)
                {
                    if (cmbFIO.Text != "" && cmbTech.Text != "") // Проверка полей
                    {
                        DataContext dc = new DataContext(connectionString);

                        Table<Classes.Users> pers = dc.GetTable<Classes.Users>();




                        // Добавление в базу
                        Classes.Act newAct = new Classes.Act { NameTech = cmbTech.Text, FIOpers = cmbFIO.Text, status = true };
                        dc.GetTable<Classes.Act>().InsertOnSubmit(newAct);
                        dc.SubmitChanges();

                        UpdateData(); // Обновление таблиц
                        UpdateCmb(); // Обновление ComboBox`ов

                        MessageBox.Show("Акт добавлен"); // Вывод сообщения
                    }
                    else
                    {
                        MessageBox.Show("Заполните все поля"); // Вывод сообщения
                    }
                }


                //Редактирование 
                else
                {
                    object item = dataAct.SelectedItem;
                    long vb = Convert.ToInt64((dataAct.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
                    DataContext dc = new DataContext(connectionString);
                    Table<Classes.Act> act = dc.GetTable<Classes.Act>();
                    Classes.Act pr = act.FirstOrDefault(pre => pre.id.Equals(vb));


                    pr.NameTech = cmbTech.Text;
                    pr.FIOpers = cmbFIO.Text;
                    pr.status = true;

                    var SelectQuery =
                        from a in act
                        select a;

                    dc.SubmitChanges();
                    dataAct.ItemsSource = SelectQuery;

                    UpdateData(); // Обновление таблиц
                    UpdateCmb(); // Обновление ComboBox`ов
                    MessageBox.Show("Данные изменены");
                    redAct = 0;
                }


                cmbFIO.Text = "";
                cmbTech.Text = "";

                btnDel3.IsEnabled = false;
                btnEnter3.IsEnabled = false;
                btnRed3.IsEnabled = false;
                btnOtm3.IsEnabled = false;

                btnNewAct.IsEnabled = true;
            }

            catch { }
        }
        // Новый акт
        private void btnNewAct_Click(object sender, RoutedEventArgs e)
        {
            cmbFIO.IsEnabled = true;
            cmbTech.IsEnabled = true;


            btnEnter3.IsEnabled = true;
            btnOtm3.IsEnabled = true;
            UpdateCmb();
        }
        // Редактирование акта
        private void btnRed3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //Доступность 


                cmbTech.IsEnabled = true;
                cmbFIO.IsEnabled = true;

                btnOtm3.IsEnabled = true;

                btnNewAct.IsEnabled = false;

                DataContext dc = new DataContext(connectionString);
                Table<Classes.Act> act = dc.GetTable<Classes.Act>();

                // Редактирование
                object item = dataAct.SelectedItem;
                long vb = Convert.ToInt64((dataAct.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);



                cmbTech.Text = (from sp in act
                                where sp.id == vb
                                select sp.NameTech).FirstOrDefault(); // Получение названия оборудования



                cmbFIO.Text = (from sp in act
                               where sp.id == vb
                               select sp.FIOpers).FirstOrDefault(); // Получение ФИО наладчика

                btnEnter3.IsEnabled = true;
                btnRed3.IsEnabled = true;

                redAct = 1;
            }
            catch { }
        }
        // Удаление акта
        private void btnDel3_Click(object sender, RoutedEventArgs e)
        {
            object item = dataAct.SelectedItem;
            long vb = Convert.ToInt64((dataAct.SelectedCells[0].Column.GetCellContent(item) as TextBlock).Text);
            DataContext dc = new DataContext(connectionString);
            Table<Classes.Act> pays = dc.GetTable<Classes.Act>();
            Classes.Act pr = pays.FirstOrDefault(pre => pre.id.Equals(vb));

            pr.status = false; // Смена статуса True на False
            var SelectQuery =
                from a in pays
                select a;

            dc.SubmitChanges();
            dataAct.ItemsSource = SelectQuery;

            UpdateData();
            MessageBox.Show("Акт удален");
        }
        // Кнопка отмены в Актах
        private void btnOtm3_Click(object sender, RoutedEventArgs e)
        {
            cmbTech.Text = "";
            cmbFIO.Text = "";

            btnDel3.IsEnabled = false;
            btnEnter3.IsEnabled = false;
            btnRed3.IsEnabled = false;
            btnOtm3.IsEnabled = false;

            cmbTech.IsEnabled = false;
            cmbFIO.IsEnabled = false;

            btnNewAct.IsEnabled = true;
        }

        private void DataPaysOT4_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnDel3.IsEnabled = true;
            btnRed3.IsEnabled = true;
        }



        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        // Кнопка Сформировать отчет
        private void btnOt4et_Click(object sender, RoutedEventArgs e)
        {
            ExportExcelFile(dataAct1);
        }

        private void ExportExcelFile(DataGrid dataGrid)
        {
            Excel.Application app = new Excel.Application();
            app.Visible = true;
            app.WindowState = Excel.XlWindowState.xlMaximized;

            Workbook wb = app.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
            Worksheet ws = wb.Worksheets[1];
            DateTime currentDate = DateTime.Now;
            ws.Columns.AutoFit();


            //Заголовок
            Range range2 = (Range)ws.Cells[1, 1];
            ws.Cells[1, 1].font.bold = true;
            ws.Cells[1, 1].columnwidth = 15;
            ws.Cells[1, 1].Value = "Отчёт";


            //Название столбцов
            for (int i = 0; i < dataGrid.Columns.Count; i++)
            {
                Range range_ = (Range)ws.Cells[2, i + 1];
                ws.Cells[2, i + 1].font.bold = true;
                ws.Cells[2, i + 1].columnwidth = 15;
                ws.Cells[2, i + 1].Borders.LineStyle =
                Excel.XlLineStyle.xlDouble;
                range_.Value2 = dataGrid.Columns[i].Header;

                //Заполнение ячеек
                for (int j = 0; j < dataGrid.Items.Count; j++)
                {
                    TextBlock text = dataGrid.Columns[i].GetCellContent(dataGrid.Items[j]) as TextBlock;
                    Range range = (Range)ws.Cells[j + 3, i + 1];
                    range.Value2 = text.Text;
                    range.Borders.LineStyle =
                    Excel.XlLineStyle.xlDouble;
                }
            }
        }

        private void cmbTech_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateCmb();
        }

        private void lblOt41_MouseDown(object sender, MouseButtonEventArgs e)
        {
            /*
            DataContext dc = new DataContext(connectionString);
            Table<Classes.Users> pays = dc.GetTable<Classes.Users>();

            var st = (from s in pays
                      where s.fio == cmbFIO1.Text && s.status == true
                      select s);
            dataAct1.ItemsSource = st;
            */
        }

        private void lblOt42_MouseDown(object sender, MouseButtonEventArgs e)
        {
            /*
            DataContext dc = new DataContext(connectionString);
            Table<Classes.Tech> pays = dc.GetTable<Classes.Tech>();

            var st = (from s in pays
                      where s.NameOfTech == cmbTech1.Text && s.status == true
                      select s);
            dataAct1.ItemsSource = st;
            */
        }

        private void cmbFIO1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateData(); // Обновление таблиц
            UpdateCmb(); // Обновление ComboBox`ов
            if (cmbFIO1.Text != "")
            {
                // Отчёт по выбранному сотруднику
                DataContext dc = new DataContext(connectionString);
                Table<Classes.Act> act = dc.GetTable<Classes.Act>();

                var st = (from s in act
                          where s.status == true && s.FIOpers.Contains(cmbFIO1.Text)
                          select s); // Получение ФИО наладчика

                dataAct1.ItemsSource = st; // Отоброжение в таблице
            }
            else
            {
                UpdateData(); // Обновление таблиц
                UpdateCmb(); // Обновление ComboBox`ов
            }
        }

        private void cmbTech1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateData(); // Обновление таблиц
            UpdateCmb(); // Обновление ComboBox`ов

            if (cmbTech1.Text != "") // Проверка на пустотму
            {
                // Отчёт по оборудованию
                DataContext dc = new DataContext(connectionString);
                Table<Classes.Act> act = dc.GetTable<Classes.Act>();

                var st = (from s in act
                          where s.status == true && s.NameTech.Contains(cmbTech1.Text)
                          select s);

                dataAct1.ItemsSource = st; // Отображение в таблице
            }
            else
            {
                UpdateData(); // Обновление таблиц
                UpdateCmb(); // Обновление ComboBox`ов
            }
        }

        private void dataAct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnDel3.IsEnabled = true;
            btnRed3.IsEnabled = true;
        }

        private void dataAct1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnDel3.IsEnabled = true;
            btnRed3.IsEnabled = true;
        }

        private void btnOtm4_Click(object sender, RoutedEventArgs e)
        {
            cmbFIO1.Text = "";
            cmbTech1.Text = "";
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            UpdateData(); // Обновление таблиц
            UpdateCmb(); // Обновление comboBox`ов

            if (role == "adjuster")
            {

                //Отчеты
                dataAct1.IsEnabled = false;
                cmbFIO1.IsEnabled = false;
                cmbTech1.IsEnabled = false;
                lblOt41.IsEnabled = false;
                lblOt42.IsEnabled = false;
                btnOtm4.IsEnabled = false;
                btnOt4et1.IsEnabled = false;
            }
        }

        private void TabItem_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
    }
}
