﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq.Mapping;

namespace AdjustmentOfEquipment.Classes
{
    [Table(Name = "Act")]
    class Act
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public int id { get; set; }
       
        [Column(Name = "NameTech")]
        public string NameTech { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }
        [Column(Name = "FIOpers")]
        public string FIOpers { get; set; }

      //  [Column(Name = "data")]
        //  public DateTime
    }
}
