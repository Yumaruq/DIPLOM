﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq.Mapping;

namespace AdjustmentOfEquipment.Classes
{
    [Table(Name = "Tech1")]
    class Tech
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public int Id { get; set; }
        [Column(Name = "NameOfTech")]
        public string NameOfTech { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }

      
    }
}
