﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Linq.Mapping;

namespace AdjustmentOfEquipment.Classes
{
    [Table(Name = "Users1")]
    class Users
    {
        [Column(IsPrimaryKey = true, IsDbGenerated = true)]
        public int id { get; set; }
        [Column(Name = "username")]
        public string username { get; set; }
        [Column(Name = "password")]
        public string password { get; set; }
        [Column(Name = "admin")]
        public string admin { get; set; }
        [Column(Name = "status")]
        public bool status { get; set; }
        [Column(Name = "fio")]
        public string fio { get; set; }
    }
}
